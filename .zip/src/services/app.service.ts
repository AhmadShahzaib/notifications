import mongoose, {
  FilterQuery,
  ProjectionType,
} from 'mongoose';
import {
  Injectable,
  Logger,
  Scope,
} from '@nestjs/common';
import { LogsDocumentContentsType } from 'logs/types';
import admin from "firebase-admin";
const serviceAccount = require("../config/logeld-firebase-adminsdk-cw4fh-d13657806c.json");
import { HttpService } from '@nestjs/axios';

const notification_options = {
  priority: "high",
  timeToLive: 60 * 60 * 24
};
// @Injectable({ scope: Scope.REQUEST })
export class AppService {
  private readonly logger = new Logger('PushNotificationService');
  constructor(private readonly httpService) { }

  sendNotificationAPI = async (payload) => {
    try {
      const url = 'https://fcm.googleapis.com/fcm/send';
      const data = {
        "to": "<FCM TOKEN>",
        "body": "Test Notification !!!",
        "title": "Test Title !!!"
      };
      // data, {
      //   headers: {
      //     "Content-Type": "application/json",
      //     "Authorization": "key=BGJCx6fOxMj6XW7EPlDHVutD-05W-tVKHCS8SfFGWNLMoGrX2zeE8kZ_7cIpCmGmPhUqM02XN7kIF12GFbbGWqg"
      //   }
      // }
      const options = {};
      const response = await this.httpService.get('google.com.pk',)
      console.log(response);

    } catch (error) {
      console.log(error);
      throw error;
    }

  }

  // sendNotification = async (data: any) => {
  //   const registrationToken = data.registrationToken;
  //   const message = data.message;
  //   const options = notification_options;

  //   admin.initializeApp({
  //     credential: admin.credential.cert(serviceAccount),
  //     databaseURL: 'https://logeld-default-rtdb.firebaseio.com/'
  //   });
  //   const payload = {
  //     notification: {
  //       title: "test",
  //       body: "this is a test notification"
  //     }
  //   }
  //   const token = await admin.auth().createCustomToken('uid');
  //   admin.messaging().sendToDevice(['eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJodHRwczovL2lkZW50aXR5dG9vbGtpdC5nb29nbGVhcGlzLmNvbS9nb29nbGUuaWRlbnRpdHkuaWRlbnRpdHl0b29sa2l0LnYxLklkZW50aXR5VG9vbGtpdCIsImlhdCI6MTY2NjcwNjU1MCwiZXhwIjoxNjY2NzEwMTUwLCJpc3MiOiJmaXJlYmFzZS1hZG1pbnNkay1jdzRmaEBsb2dlbGQuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20iLCJzdWIiOiJmaXJlYmFzZS1hZG1pbnNkay1jdzRmaEBsb2dlbGQuaWFtLmdzZXJ2aWNlYWNjb3VudC5jb20iLCJ1aWQiOiJ1aWQifQ.UnQvgevcOG_XjY9S_9ulTrS4kVIJVT_cDZGxffSQYX7_Hc4Y1RHPBDrF5QsCsHnU_h4qoQ9QvPyw2ziO-puOAf8dmZVmNE8WtE5a1iuRtQf-wEyy50HR_Nku09ptBNHjvUsShtllUTSrJWjN-VaMHwODcv-xE6aRe_TSXvYz18p5dRXJiyktNyyQpFTrOTtPx7jjDRGApJ1IO6mkYcFJF-rHYqbXXqwczR6boBYq3UrBoFxQzrElqZ6mio6hg7F9ffOuCl7vQ9c-I8PPlJq9ixHDX1uTudCwNPDbLhJgvVELk4UwfyIyIRoUlEP_BgRAxDIG_9acarXAkwf3gPRx9A'], payload, options)
  //     .then(response => {

  //       console.log(response);

  //       // res.status(200).send("Notification sent successfully")

  //     })
  //     .catch(error => {
  //       console.log(error);
  //     });

  // };

}
