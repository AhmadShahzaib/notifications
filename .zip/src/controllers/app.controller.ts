import {
  Controller,
  Inject,
  Res,
  Logger,
  Post,
} from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Response } from 'express';
import { mapKeys, camelCase } from 'lodash';

import { AppService } from '../services/app.service';

@Controller('PushNotification')
@ApiTags('PushNotification')
export class AppController {
  private readonly logger = new Logger('PushNotification App Controller');
  private readonly snakeCaseMapper = (val) =>
    mapKeys(val, (v, k) => {
      return camelCase(k);
    });
  constructor(
    @Inject('AppService') private readonly appService: AppService
  ) { }

  @Post('test')
  async sendNotification(
    @Res() response: Response,
  ) {
    try {
      await this.appService.sendNotificationAPI({ registrationToken: "", message: "Hellor World" });
      return response.status(200).send({
        message: 'Success',
        data: [],
      });
    } catch (error) {
      throw error;
    }
  }
}
